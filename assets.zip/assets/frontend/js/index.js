/**
 * Import JS files for each frontend page here
 */

// import "./pages/booking";
import "./pages/order";
import "./pages/menus";
import "./pages/order-now";
import "./pages/checkout";
